# Chapter 2 Exercises

This repository contains programming exercises for working with the command-line, 
based on [Chapter 2](https://infx511.github.io/command-line.html) 
of the [Introduction to Programming for Information and Data Science](https://infx511.github.io/) course book. 

Solutions can be found in the `solution` branch.